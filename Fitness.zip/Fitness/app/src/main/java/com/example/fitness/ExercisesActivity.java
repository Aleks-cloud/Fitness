package com.example.fitness;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.OneShotPreDrawListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ExercisesActivity extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercises);
        Button button14 = (Button) findViewById(R.id.button14);
        Button button13 = (Button) findViewById(R.id.button13);
        Button button5 = (Button) findViewById(R.id.button5);
        button14.setOnClickListener(this);
        button13.setOnClickListener(this);
        button5.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button14:
                Intent intent = new Intent(ExercisesActivity.this, BicepsActivity.class);
                startActivity(intent);
                break;
            case R.id.button13:
                Intent intent1 = new Intent(ExercisesActivity.this, ShouldersActivity.class);
                startActivity(intent1);
                break;
            case R.id.button16:
                Intent intent2 = new Intent(ExercisesActivity.this, ChestActivity.class);
                startActivity(intent2);
                break;
            case R.id.button5:
                Intent intent3 = new Intent(ExercisesActivity.this, NeckActivity.class);
                startActivity(intent3);
                break;
        }
    }
}
