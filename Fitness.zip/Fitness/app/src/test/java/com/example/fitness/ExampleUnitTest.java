package com.example.fitness;

import org.junit.Test;
import org.junit.experimental.categories.Category;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition1_isCorrect() throws Exception {

        ExercisesActivity exercisesActivity = new ExercisesActivity();
        long result = exercisesActivity.getIntent();
        long expected = 2;
        assertEquals(expected, result);

    }

    @Test
    public void addition2_isCorrect() throws Exception {
        WorkoutActivity workoutActivity = new WorkoutActivity();
        String result = workoutActivity.getPackageName();
        String expected = "3";
        assertEquals(expected, result);
    }
}